#How to use the pot file#

The pot file include in this folder is ready to use.

1. Double click on it and open it with poedit

2. In poedit goto File -> New Catalog from POT file...

3. Select and Open the pot file from the languages folder

4. Enter your name, email address, your language and country (i.e. french fr_FR, german de_DE) to the setting form 

5. Click the update button in the main poedit ui.

6. Save the file :
	- For a plugin like filename-xx_XX.po with xx_XX for your language and country.
	- For a theme xx_XX.po

Thank you for your contribution

#####

Place your theme language files in this directory.

Please visit the following links to learn more about translating WordPress themes:

https://make.wordpress.org/polyglots/teams/
https://developer.wordpress.org/themes/functionality/localization/
https://developer.wordpress.org/reference/functions/load_theme_textdomain/
